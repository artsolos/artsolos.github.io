// Extracted from EECE 2323 Lab 2 report; report formatting normalized.
module alu( 
    input  logic signed [15:0] a, 
    input  logic signed [15:0] b, 
    input  logic [3:0] s, 
    output logic signed [15:0] f, 
    output logic ovf, 
    output logic take_branch 
); 
 
always_comb begin 
        // Default values 
        f = 16'h0000; 
        ovf = 1'b0; 
        take_branch = 1'b0; 
        case (s) 
            // ADD: f = a + b 
            4'b0000: begin 
                f = a + b; 
                // Overflow happens when a and b have the same sign, 
                // but the result has a different sign. 
                if ((a[15] == b[15]) && (f[15] != a[15])) 
                    ovf = 1'b1; 
                else 
                    ovf = 1'b0; 
                take_branch = 1'b0; 
            end 
            // INV: f = bitwise inversion of b 
            4'b0001: begin 
                f = ~b; 
                ovf = 1'b0; 
                take_branch = 1'b0; 
            end 
            // AND: f = a AND b 
            4'b0010: begin 
                f = a & b; 
                ovf = 1'b0; 
                take_branch = 1'b0; 
            end 
            // OR: f = a OR b 
            4'b0011: begin 
                f = a | b; 
                ovf = 1'b0; 
                take_branch = 1'b0; 
            end 
            // SRA: arithmetic right shift 
            4'b0100: begin 
 
                f = a >>> b; 
                ovf = 1'b0; 
                take_branch = 1'b0; 
            end 
            // SLL: logical left shift 
            4'b0101: begin 
                f = a << b; 
                ovf = 1'b0; 
                take_branch = 1'b0; 
            end 
            // BEQZ: branch if a equals zero 
            4'b0110: begin 
                f = 16'h0000; 
                ovf = 1'b0; 
 
                if (a == 16'h0000) 
                    take_branch = 1'b1; 
                else 
                    take_branch = 1'b0; 
            end 
 
            // BNEZ: branch if a does not equal zero 
            4'b0111: begin 
                f = 16'h0000; 
                ovf = 1'b0; 
 
                if (a != 16'h0000) 
                    take_branch = 1'b1; 
                else 
                    take_branch = 1'b0; 
            end 
 
            // XOR: f = a XOR b 
            4'b1000: begin 
                f = a ^ b; 
                ovf = 1'b0; 
                take_branch = 1'b0; 
 
            end 
 
            // Any unused selector value 
            default: begin 
                f = 16'h0000; 
                ovf = 1'b0; 
                take_branch = 1'b0; 
            end 
 
        endcase 
    end 
endmodule

// Extracted from EECE 2323 Lab 2 report; report formatting normalized.
module alu_tb; 
    logic signed [15:0] a; 
    logic signed [15:0] b; 
    logic [3:0] s; 
    logic signed [15:0] f; 
    logic ovf; 
    logic take_branch; 
 
    alu dut ( 
        .a(a), 
        .b(b), 
        .s(s), 
        .f(f), 
        .ovf(ovf), 
        .take_branch(take_branch) 
    ); 
    initial begin 
        // ADD normal 
        a = 16'h0003; b = 16'h0004; s = 4'b0000; 
        // ADD positive overflow 
        #100 a = 16'h7FFF; b = 16'h0001; s = 4'b0000; 
        // ADD negative overflow 
        #100 a = 16'h8000; b = 16'hFFFF; s = 4'b0000; 
 
        // INV 
        #100 a = 16'h0000; b = 16'h00FF; s = 4'b0001; 
        // AND 
        #100 a = 16'h00F0; b = 16'h0F0F; s = 4'b0010; 
        // OR 
        #100 a = 16'h00F0; b = 16'h0F0F; s = 4'b0011; 
        // SRA 
        #100 a = 16'hFFF0; b = 16'h0002; s = 4'b0100; 
        // SLL 
        #100 a = 16'h0003; b = 16'h0004; s = 4'b0101; 
        // BEQZ true 
        #100 a = 16'h0000; b = 16'h0000; s = 4'b0110; 
        // BEQZ false 
        #100 a = 16'h0005; b = 16'h0000; s = 4'b0110; 
        // BNEZ true 
        #100 a = 16'h0005; b = 16'h0000; s = 4'b0111; 
        // BNEZ false 
        #100 a = 16'h0000; b = 16'h0000; s = 4'b0111; 
        // XOR 
        #100 a = 16'h00FF; b = 16'h0F0F; s = 4'b1000; 
        // Default unused selector 
        #100 a = 16'h1111; b = 16'h2222; s = 4'b1111; 
        #100 $stop; 
    end 
endmodule

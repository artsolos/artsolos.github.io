// Extracted from EECE 2323 Lab 6 report; report formatting normalized.
module program_counter( 
    input logic clk, 
    input logic rst, 
    output logic [7:0] pc 
); 
 
always_ff @(posedge clk or posedge rst) begin 
    if (rst) 
        pc <= 8'b00000000; 
    else 
        pc <= pc + 1; 
end 
endmodule

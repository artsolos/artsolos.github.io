// Extracted from EECE 2323 Lab 5 report; report formatting normalized.
module inst_decoder_tb(); 
 
// input signals going into the decoder 
logic [6:0] immediate; 
logic [5:0] nzimm; 
logic [8:0] offset; 
logic [3:0] opcode; 
 
// output signals coming from the decoder 
logic RegWrite; 
logic RegDst; 
logic [15:0] instr_i; 
logic ALUSrc1; 
logic ALUSrc2; 
logic [3:0] ALUOp; 
logic MemWrite; 
logic MemToReg; 
logic Regsrc; 
 
// connect the testbench signals to the instruction decoder 
instruction_decoder UUT ( 
    .immediate(immediate), 
    .nzimm(nzimm), 
    .offset(offset), 
    .opcode(opcode), 
    .RegWrite(RegWrite), 
    .RegDst(RegDst), 
    .instr_i(instr_i), 
    .ALUSrc1(ALUSrc1), 
    .ALUSrc2(ALUSrc2), 
    .ALUOp(ALUOp), 
    .MemWrite(MemWrite), 
    .MemToReg(MemToReg), 
    .Regsrc(Regsrc) 
); 
 
// start the test 
initial begin 
 
    // test values for the immediate fields 
    immediate = 7'b0000101; 
    nzimm     = 6'b000011; 
    offset    = 9'b000000100; 
 
    // first opcode starts at time 0 
    opcode = 4'b0000; // lw 
 
    // test every opcode from the lab 5 prelab table 
    #100 opcode = 4'b0001; // sw 
    #100 opcode = 4'b0010; // add 
 
    #100 opcode = 4'b0011; // addi 
    #100 opcode = 4'b0100; // and 
    #100 opcode = 4'b0101; // andi 
    #100 opcode = 4'b0110; // or 
    #100 opcode = 4'b0111; // xor 
    #100 opcode = 4'b1000; // srai 
    #100 opcode = 4'b1001; // slli 
    #100 opcode = 4'b1010; // beqz 
    #100 opcode = 4'b1011; // bneqz 
 
    // test invalid opcode to make sure default values work 
    #100 opcode = 4'b1111; // invalid 
 
    // wait before ending simulation 
    #100 $finish; 
end 
 
endmodule

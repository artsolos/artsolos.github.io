// Extracted from EECE 2323 Lab 5 report; report formatting normalized.
module instruction_decoder ( 
    // input fields from vio / mapper 
    input  logic [6:0] immediate, 
    input  logic [5:0] nzimm, 
    input  logic [8:0] offset, 
    input  logic [3:0] opcode, 
 
    // output control signals for the datapath 
    output logic RegWrite, 
    output logic RegDst, 
    output logic [15:0] instr_i, 
    output logic ALUSrc1, 
    output logic ALUSrc2, 
    output logic [3:0] ALUOp, 
    output logic MemWrite, 
    output logic MemToReg, 
    output logic Regsrc 
); 
 
// combinational decoder logic 
always_comb begin 
 
    // default values so nothing random happens 
    RegWrite = 1'b0; 
    RegDst   = 1'b0; 
    instr_i  = 16'h0000; 
    ALUSrc1  = 1'b0; 
    ALUSrc2  = 1'b0; 
    ALUOp    = 4'b0000; 
    MemWrite = 1'b0; 
    MemToReg = 1'b0; 
    Regsrc   = 1'b0; 
 
    // choose control signals based on opcode 
    case (opcode) 
 
        // lw: load word from data memory into register 
        4'b0000: begin 
            RegWrite = 1'b1; 
            RegDst   = 1'b1; 
            instr_i  = {{9{immediate[6]}}, immediate}; 
            ALUSrc1  = 1'b0; 
            ALUSrc2  = 1'b1; 
            ALUOp    = 4'b0000; 
            MemWrite = 1'b0; 
 
            MemToReg = 1'b1; 
            Regsrc   = 1'b0; 
        end 
 
        // sw: store register value into data memory 
        4'b0001: begin 
            RegWrite = 1'b0; 
            instr_i  = {{9{immediate[6]}}, immediate}; 
            ALUSrc1  = 1'b0; 
            ALUSrc2  = 1'b1; 
            ALUOp    = 4'b0000; 
            MemWrite = 1'b1; 
            MemToReg = 1'b0; 
            Regsrc   = 1'b0; 
        end 
 
        // add: add two register values 
        4'b0010: begin 
            RegWrite = 1'b1; 
            RegDst   = 1'b1; 
            ALUSrc1  = 1'b0; 
            ALUSrc2  = 1'b0; 
            ALUOp    = 4'b0000; 
            MemWrite = 1'b0; 
            MemToReg = 1'b0; 
            Regsrc   = 1'b0; 
        end 
 
        // addi: add register value with immediate 
        4'b0011: begin 
            RegWrite = 1'b1; 
            RegDst   = 1'b1; 
            instr_i  = {{10{nzimm[5]}}, nzimm}; 
            ALUSrc1  = 1'b0; 
            ALUSrc2  = 1'b1; 
            ALUOp    = 4'b0000; 
            MemWrite = 1'b0; 
            MemToReg = 1'b0; 
            Regsrc   = 1'b0; 
        end 
 
        // and: bitwise and using two registers 
        4'b0100: begin 
            RegWrite = 1'b1; 
            RegDst   = 1'b1; 
            ALUSrc1  = 1'b0; 
            ALUSrc2  = 1'b0; 
            ALUOp    = 4'b0010; 
            MemWrite = 1'b0; 
            MemToReg = 1'b0; 
            Regsrc   = 1'b0; 
        end 
 
 
        // andi: bitwise and using register and immediate 
        4'b0101: begin 
            RegWrite = 1'b1; 
            RegDst   = 1'b1; 
            instr_i  = {{9{immediate[6]}}, immediate}; 
            ALUSrc1  = 1'b0; 
            ALUSrc2  = 1'b1; 
            ALUOp    = 4'b0010; 
            MemWrite = 1'b0; 
            MemToReg = 1'b0; 
            Regsrc   = 1'b0; 
        end 
 
        // or: bitwise or using two registers 
        4'b0110: begin 
            RegWrite = 1'b1; 
            RegDst   = 1'b1; 
            ALUSrc1  = 1'b0; 
            ALUSrc2  = 1'b0; 
            ALUOp    = 4'b0011; 
            MemWrite = 1'b0; 
            MemToReg = 1'b0; 
            Regsrc   = 1'b0; 
        end 
 
        // xor: bitwise xor using two registers 
        4'b0111: begin 
            RegWrite = 1'b1; 
            RegDst   = 1'b1; 
            ALUSrc1  = 1'b0; 
            ALUSrc2  = 1'b0; 
            ALUOp    = 4'b1000; 
            MemWrite = 1'b0; 
            MemToReg = 1'b0; 
            Regsrc   = 1'b0; 
        end 
 
        // srai: arithmetic shift right immediate 
        4'b1000: begin 
            RegWrite = 1'b1; 
            RegDst   = 1'b1; 
            instr_i  = {{10{nzimm[5]}}, nzimm}; 
            ALUSrc1  = 1'b0; 
            ALUSrc2  = 1'b1; 
            ALUOp    = 4'b0100; 
            MemWrite = 1'b0; 
            MemToReg = 1'b0; 
            Regsrc   = 1'b0; 
        end 
 
        // slli: shift left logical immediate 
        4'b1001: begin 
            RegWrite = 1'b1; 
 
            RegDst   = 1'b1; 
            instr_i  = {{10{nzimm[5]}}, nzimm}; 
            ALUSrc1  = 1'b0; 
            ALUSrc2  = 1'b1; 
            ALUOp    = 4'b0101; 
            MemWrite = 1'b0; 
            MemToReg = 1'b0; 
            Regsrc   = 1'b0; 
        end 
 
        // beqz: branch if value equals zero 
        4'b1010: begin 
            RegWrite = 1'b0; 
            instr_i  = {{7{offset[8]}}, offset}; 
            ALUSrc1  = 1'b0; 
            ALUSrc2  = 1'b0; 
            ALUOp    = 4'b0110; 
            MemWrite = 1'b0; 
            MemToReg = 1'b0; 
            Regsrc   = 1'b1; 
        end 
 
        // bneqz: branch if value does not equal zero 
        4'b1011: begin 
            RegWrite = 1'b0; 
            instr_i  = {{7{offset[8]}}, offset}; 
            ALUSrc1  = 1'b0; 
            ALUSrc2  = 1'b0; 
            ALUOp    = 4'b0111; 
            MemWrite = 1'b0; 
            MemToReg = 1'b0; 
            Regsrc   = 1'b1; 
        end 
 
        // default: invalid opcode, no write happens 
        default: begin 
            RegWrite = 1'b0; 
            RegDst   = 1'b0; 
            instr_i  = 16'h0000; 
            ALUSrc1  = 1'b0; 
            ALUSrc2  = 1'b0; 
            ALUOp    = 4'b0000; 
            MemWrite = 1'b0; 
            MemToReg = 1'b0; 
            Regsrc   = 1'b0; 
        end 
 
    endcase 
end 
 
endmodule

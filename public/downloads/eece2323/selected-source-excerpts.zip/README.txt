EECE 2323 — selected code excerpts from Arefin Mahmood's lab reports

These are text recovered from the supplied reports, with page headers removed
and typographic apostrophes normalized. They are excerpts, not the original
Vivado project archive. No standalone project/source ZIP or nested ZIP was
included in the supplied archive. Do not infer that missing modules were written
or reconstructed here.

Included: Lab 1 adder and testbench; Lab 2 ALU and testbench; Lab 3 register file
and mux; Lab 5 instruction decoder and testbench; Lab 6 sequential PC; Lab 7
branching PC, assembly listing and output.coe. Different labs contain different
versions of modules and must remain in their separate directories.

Course support wrappers, board constraints, generated VIO/memory IP and the final
mapper/integration project are not bundled. Use the PDFs to understand context.
The recovered code has not been rerun in Vivado or on FPGA hardware here.

Scope of results: the user confirmed individual labs and only the documented
4 x 3 hardware multiplication test. Negative/zero multiplier paths are unverified.
Lab 7 Figure C15 shows read data 000C at PC 00F but live ALU/writeback 0018;
the end instruction must not be treated as a verified halt or result-preserving
instruction. The supplied assembly/COE are retained as evidence, not silently fixed.
Lab 6's final PC labels differ between its table and captions; exact final-index
claims are omitted from the website.

No student IDs, contact details, instructor identity or local machine paths are
included in these source excerpts. Instructor identity and PDF metadata were
removed separately from the public report copies. Original files remain private.

// Extracted from EECE 2323 Lab 1 report; report formatting normalized.
module adder16_tb; 
    logic [15:0] a; 
    logic [15:0] b; 
    logic [15:0] f; 
    logic        ovf; 
 
    sixteenbit_adder dut ( 
        .a(a), 
        .b(b), 
 
        .f(f), 
        .ovf(ovf) 
    ); 
 
initial begin 
    a = 16'h0025; b = 16'h0045; 
    #100 a = 16'h7FFF; b = 16'h0001; 
    #100 a = 16'hA415; b = 16'hA555; 
    #100 a = 16'hF115; b = 16'hF215; 
    #100 a = 16'h9D00; b = 16'h9E00; 
    #100 a = 16'hED00; b = 16'hEF03; 
    #100 a = 16'h8A10; b = 16'h7110; 
    #100 a = 16'h21AA; b = 16'h21BB; 
    #100 a = 16'h9A00; b = 16'h9F4F; 
    #100 a = 16'h0040; b = 16'h0050; 
    #100 $finish; 
end 
endmodule

// Extracted from EECE 2323 Lab 1 report; report formatting normalized.
module sixteenbit_adder( 
    input  logic [15:0] a, 
    input  logic [15:0] b, 
    output logic [15:0] f, 
    output logic        ovf 
); 
    assign f = a + b; 
    assign ovf = (~(a[15] ^ b[15])) & (a[15] ^ f[15]); 
endmodule

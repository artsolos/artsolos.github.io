// Extracted from EECE 2323 Lab 3 report; report formatting normalized.
module TwoToOneMux( 
    input logic [15:0] a,        // First input. Chosen when sel_mux = 0. 
    input logic [15:0] b,        // Second input. Chosen when sel_mux = 1. 
    input logic sel_mux,         // Select signal for the mux. 
    output logic [15:0] out      // Output of the mux. 
); 
 
    // If sel_mux is 0, out = a. 
    // If sel_mux is 1, out = b. 
    assign out = sel_mux ? b : a; 
endmodule

// Extracted from EECE 2323 Lab 3 report; report formatting normalized.
module regfile( 
    input logic rst,                  // reset signal all registers to 0 
 
    input logic clk,                  // clock signal 
    input logic wr_en,                // rite enable 
    input logic [2:0] rd0_addr,       // address for first read port 
    input logic [2:0] rd1_addr,       // address for second read port 
    input logic [2:0] wr_addr,        // address for write port 
    input logic [15:0] wr_data,       // data that will be written into the register file 
    output logic [15:0] rd0_data,     // read from rd0_addr 
    output logic [15:0] rd1_data      //read from rd1_addr 
); 
 
    //creates 8 registers.each register stores 16 bits. 
    logic [15:0] registers [0:7]; 
    integer i; 
 
    // block handles reset and writing 
    // It only changes values on the rising edge of the clock 
    always_ff @(posedge clk) begin 
 
        // if reset is on, clear all registers to 0. 
        if (rst) begin 
            for (i = 0; i < 8; i = i + 1) begin 
                registers[i] <= 16'd0; 
            end 
        end 
 
        // if reset is off and write enable is on, write data. 
        else if (wr_en) begin 
            registers[wr_addr] <= wr_data; 
        end 
    end 
 
    // these are the two read outputs. they show the values stored at the selected read addresses. 
    assign rd0_data = registers[rd0_addr]; 
 
    assign rd1_data = registers[rd1_addr]; 
endmodule

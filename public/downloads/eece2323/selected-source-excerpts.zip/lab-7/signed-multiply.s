init: 
    addi x8, x8, 4         # set x8 to 4 
    addi x9, x9, 3         # set x9 to 3 
    add  x11, x11, x9      # copy x9 into counter x11 
    beqz x11, done         # if counter is 0, go to done 
    srai x9, x9, 7         # check if multiplier is negative 
    bnez x9, neg_setup     # if negative, go to negative setup 
pos_loop: 
    add  x10, x10, x8      # add x8 to product x10 
    addi x11, x11, -1      # subtract 1 from counter 
    bnez x11, pos_loop     # repeat if counter is not 0 
    beqz x11, done         # go to done when counter is 0 
neg_setup: 
    xor  x8, x8, x9        # flip x8 bits 
    addi x8, x8, 1         # make x8 negative 
neg_loop: 
    add  x10, x10, x8      # add negative x8 to product 
    addi x11, x11, 1       # add 1 to counter 
    bnez x11, neg_loop     # repeat if counter is not 0 
done: 
    addi x10, x10, 0       # keep final result in x10

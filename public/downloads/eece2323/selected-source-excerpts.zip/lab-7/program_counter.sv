// Extracted from EECE 2323 Lab 7 report; report formatting normalized.
module program_counter( 
    input  logic clk, 
    input  logic rst, 
    input  logic take_branch, 
    input  logic signed [8:0] offset, 
    output logic [8:0] pc 
); 
always_ff @(posedge clk or posedge rst) begin 
    if (rst) begin 
        pc <= 9'd0; 
    end 
    else begin 
        if (take_branch) begin 
            pc <= pc + offset; 
        end 
        else begin 
            pc <= pc + 9'd1; 
        end 
    end 
end 
endmodule

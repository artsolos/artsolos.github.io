### Question 2
def find_gpa(*args):
    # if numb of inputs is even
    if len(args) % 2 != 0:
        print("Error: Please enter credit and grade in pairs.")
        return -1

    total_credits = 0
    total_points = 0

    for i in range(0, len(args), 2):
        credit = args[i]
        grade = args[i + 1]
        total_credits += credit
        total_points += credit * grade

    gpa = total_points / total_credits
    return round(gpa, 2)

#test cases
print(find_gpa(3, 3.20, 4, 2.80, 2, 3.70))
print(find_gpa(3, 3.20, 4))






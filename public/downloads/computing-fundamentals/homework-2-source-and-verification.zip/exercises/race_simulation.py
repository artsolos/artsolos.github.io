### Question 3
import random
def tortoise_move(pos):
    i = random.randint(1, 120)
    #print("tortoise roll:i)#used for test
    if 1 <= i <= 36:            #fast plod
        pos += 3
    elif 37 <= i <= 60: #slip
        pos -= 6
    else:  #slowplod
        pos += 1

    if pos < 1:
        pos = 1
    return pos

def hare_move(pos):
    i = random.randint(1, 120)
    #print("hare roll:", i)  # testin values
    if 1 <= i <= 20:      #sleep, no move
        pass
    elif 21 <= i <= 30:  #big hop
        pos += 8
    elif 31 <= i <= 40: #big slip
        pos -= 10
    elif 41 <= i <= 88: #small hop
        pos += 1
    else:   #small slip
        pos -= 2

    if pos < 1:
        pos = 1
    return pos

def display_course(t_pos, h_pos):
    track = ["-"] * 60

    if t_pos == h_pos:
        track[t_pos - 1] = "OUCH!"
    else:
        if t_pos <= 60:
            track[t_pos - 1] = "T"
        if h_pos <= 60:
            track[h_pos - 1] = "H"

    #for displayin race
    print("".join(str(s).ljust(1) for s in track))

def run_race():
    t = 1 #tortoise pos
    h = 1 #hare pos
    print("BAnnG! AND THEY'RE OFF!!")
    while t < 60 and h < 60:
        t = tortoise_move(t)
        h = hare_move(h)
        display_course(t, h)
        if t >= 60 and h >= 60:
            print("It's a TIE.")
            return "Tie"
        elif t >= 60:
            print("TORTOISE WINS!!! YAY!!!")
            return "Tortoise"
        elif h >= 60:
            print("HARE WINS. YUCH.")
            return "Hare"
def simulate_races():
    t_w = 0
    h_w = 0
    ties = 0

    for x in range(50): #simlate 50 times
        #if it loops
        result = run_race()
        if result == "Tortoise":
            t_w += 1
        elif result == "Hare":
            h_w += 1
        else:
            ties += 1

        print("-" * 70)

    print("FINAL RESULTS AFTER 50 RACES")
    print("Tortoise wins:", t_w)
    print("Hare wins:", h_w)
    print("Ties:", ties)

#running sim
simulate_races()





### Question 5
def tennis_score(score, player1, player2):
    points_text = ["Love", "Fifteen", "Thirty", "Forty"]

    #split and convert scres
    p1, p2 = score.split(":")
    p1 = int(p1)
    p2 = int(p2)

    #deuce
    if p1 >= 3 and p2 >= 3:
        if p1 == p2:
            return "Deuce"
        elif abs(p1 - p2) == 1:
            return "Advantage " + (player1 if p1 > p2 else player2)
        elif abs(p1 - p2) >= 2:
            return "Game " + (player1 if p1 > p2 else player2)

    #agme win without deuce
    if p1 >= 4 and p1 - p2 >= 2:
        return "Game " + player1
    if p2 >= 4 and p2 - p1 >= 2:
        return "Game " + player2

    #normal score
    return f"{points_text[p1]} {points_text[p2]}"

print(tennis_score("1:0", "Alex", "Sarah"))
print(tennis_score("3:3", "Alex", "Sarah"))
print(tennis_score("2:2", "Alex", "Sarah"))
print(tennis_score("4:3", "Alex", "Sarah"))
print(tennis_score("6:4", "Alex", "Sarah"))




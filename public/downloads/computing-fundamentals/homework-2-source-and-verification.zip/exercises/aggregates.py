### Question 1
def sum_product(*numbers, in_mode=0):
    if len(numbers) == 0:
        return None, None

    if in_mode == 0:
        # tminimum and total sum
        smallest = numbers[0]
        total = 0
        for n in numbers:
            if n < smallest:
                smallest = n
            total += n
        return smallest, total
    else:
        # te maximum and total product
        largest = numbers[0]
        result = 1
        for n in numbers:
            if n > largest:
                largest = n
            result *= n
        return largest, result

print(sum_product(1, 2, 3, 4))
print(sum_product(1, 2, 3, 4, in_mode=1))
print(sum_product())





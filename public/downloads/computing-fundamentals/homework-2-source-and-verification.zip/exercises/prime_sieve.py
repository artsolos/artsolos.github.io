### Question 4
def sieve_primes(limit):
    #step a: start with all numbers marked true (maybe prime)
    primes = [True] * limit

    #0 and 1 are not prim
    primes[0] = False
    primes[1] = False

    #step b/c: mark non-primes (not prime ones)
    p = 2
    while p * p < limit:
        if primes[p]:
            # mark all multples of p as False
            for i in range(p * 2, limit, p):
                primes[i] = False
        p += 1  # go to next
    return primes

#check primes under 25000 (limit)
limit = 25000
prime_flags = sieve_primes(limit)
#print all the prime numz under 25000
for i in range(len(prime_flags)):
    if prime_flags[i]:
        print(i)






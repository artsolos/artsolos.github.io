### Question 6
import os

# make the data.txt if it aint there yet
def create_sample_file():
    if not os.path.exists("data.txt"):
        with open("data.txt", "w") as f:
            f.write("SMP613NZBEXAR: Samsung Galaxy Tab S6 Lite 64GB, $344.99, 10\n")
            f.write("APL555AIRPODS: Apple AirPods Pro 2nd Gen, $249.99, 8\n")
            f.write("BOK897234BOOK: The Alchemist by Paulo Coelho, $12.50, 25\n")
            f.write("LGTV2023123: LG 55\" OLED TV, $999.99, 3\n")

# load all the stuff from the file
def load_products():
    stuff = []
    try:
        with open("data.txt", "r") as f:
            for line in f:
                try:
                    upc, rest = line.strip().split(":")
                    name, price, qty = [x.strip() for x in rest.split(",")]
                    stuff.append({
                        "upc": upc,
                        "name": name,
                        "price": float(price.strip("$")),
                        "qty": int(qty)
                    })
                except:
                    print("oops bad line, skipped it")
    except:
        print("uhh file not found?")
    return stuff

# save back the stuff
def save_products(stuff):
    with open("data.txt", "w") as f:
        for p in stuff:
            f.write(f"{p['upc']}: {p['name']}, ${p['price']:.2f}, {p['qty']}\n")

# 1 - add new item
def add_product():
    upc = input("UPC? ")
    name = input("Name? ")
    try:
        price = float(input("Price? "))
        qty = int(input("Qty? "))
    except:
        print("nah thats not right")
        return
    with open("data.txt", "a") as f:
        f.write(f"{upc}: {name}, ${price:.2f}, {qty}\n")
    print("added it!")

# 2 - change item quantity
def update_quantity():
    upc = input("UPC to update? ")
    try:
        new_qty = int(input("New quantity? "))
    except:
        print("not a number bro")
        return
    stuff = load_products()
    found = False
    for p in stuff:
        if p["upc"] == upc:
            p["qty"] = new_qty
            found = True
            break
    if found:
        save_products(stuff)
        print("updated yay")
    else:
        print("couldnt find it")

# 3 - total value of everything
def total_value():
    stuff = load_products()
    total = sum(p["price"] * p["qty"] for p in stuff)
    print(f"Total value: ${total:.2f}")

# 4 - most expensive item
def most_expensive():
    stuff = load_products()
    if not stuff:
        print("nothing here")
        return
    maxp = max(stuff, key=lambda p: p["price"])
    print(f"{maxp['name']} - ${maxp['price']:.2f}")

# 5 - show item with lowest qty
def lowest_qty():
    stuff = load_products()
    if not stuff:
        print("file empty :(")
        return
    minp = min(stuff, key=lambda p: p["qty"])
    print(f"{minp['name']} - only {minp['qty']} left")

# 6 - show stuff with low stock
def below_qty():
    try:
        n = int(input("Show items below what qty? "))
    except:
        print("enter a real number bruh")
        return
    stuff = load_products()
    found = False
    for p in stuff:
        if p["qty"] < n:
            print(f"{p['name']} - {p['qty']}")
            found = True
    if not found:
        print("all good")

# 7 - sort stuff by price low to high
def sort_by_price():
    stuff = load_products()
    stuff.sort(key=lambda p: p["price"])
    save_products(stuff)
    print("sorted them!")

# menu menu menu
def menu():
    create_sample_file()
    while True:
        print("\n--- INVENTORY MENU ---")
        print("1. Add product")
        print("2. Update quantity")
        print("3. Show total value")
        print("4. Show most expensive")
        print("5. Show lowest quantity")
        print("6. Show all below a quantity")
        print("7. Sort by price")
        print("8. Exit")
        choice = input("Pick 1-8: ")

        if choice == "1":
            add_product()
        elif choice == "2":
            update_quantity()
        elif choice == "3":
            total_value()
        elif choice == "4":
            most_expensive()
        elif choice == "5":
            lowest_qty()
        elif choice == "6":
            below_qty()
        elif choice == "7":
            sort_by_price()
        elif choice == "8":
            print("bye bye")
            break
        else:
            print("wrong number try again")

# run ittt
menu()
Computing Fundamentals — Homework 2 Python source

ORIGINAL SUBMISSION VERSUS VERIFICATION
Original: HW2Mahmood.ipynb, one Python code cell. The supplied notebook has no
saved outputs or execution count. Its six-question code is exported without
logic changes to hw2_complete.py and exercises/*.py. The notebook copy has
normalized metadata and empty outputs; original submissions remain private and
unchanged. The source uses only Python standard-library random and os.

New verification: Python 3.12.14 on 2026-10-25. The unchanged full cell and all
six exports exited normally. The race run used harness seed 0; the inventory
menu received harness input 8. Other examples and product data came from the
submitted code. Fifteen targeted functional checks passed and three known
boundary failures were reproduced. verification.json contains scope and results.
These are new portfolio checks, not original saved results or a broad guarantee.

RUN
python hw2_complete.py
python exercises/aggregates.py
python exercises/weighted_gpa.py
python exercises/race_simulation.py
python exercises/prime_sieve.py
python exercises/tennis_scoring.py
python exercises/inventory.py

The full program prints races and primes before the interactive menu. Inventory
creates/updates data.txt in the working directory; use a disposable directory
for experiments. Run only one inventory instance against a given data file.
No external packages are required for these supplied scripts.

KNOWN LIMITATIONS — PRESERVED, NOT SILENTLY FIXED
find_gpa with zero total credits raises ZeroDivisionError; sieve_primes with a
limit below two raises IndexError; display_course(61,61) raises IndexError. The
seed-0 batch completes, but does not rule out other race failures. Inventory
accepts a simple delimiter-based format and has broad exception handlers; robust
CSV quoting, numeric validation and concurrent editing are not established.

AUTHORSHIP
The user confirmed individual work. Assignment wording/examples and the original
code comments remain part of the submission; no claims about externally authored
libraries or production use are added. Verification harness files are separate
and are not portrayed as original submissions.

HOMEWORK 1 AVAILABILITY
The archive also contained six Visual Studio .pyproj files referencing missing
.py files. Those scripts were not reconstructed or run. A separate public PDF
preserves original Homework 1 screenshots. Missing scripts: BinarytoDecimal.py,
GuessNumber.py, MaclaurinLnApprox.py, PalindromeChecker.py, PiApproximation.py,
ShoppingCart.py. Project metadata is preserved privately, not advertised as
complete executable source.

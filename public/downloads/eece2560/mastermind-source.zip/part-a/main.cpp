// Project 1 Mastermind Part A
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Main program for Project Mastermind Part A this initializes a secret code
// runs our functions to see if we get the expected values for correct and incorrect 
// when we check our user guess against the generated code 
//

#include "code.h"
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <vector>

using namespace std;

static void printResult(const code &secret, const code &guess)
// Prints the guess and our correct and incorrect response
{
   int correct = secret.checkCorrect(guess);
   int incorrect = secret.checkIncorrect(guess);

   cout << "Guess " << guess << " -> (correct, incorrect) = ("
        << correct << ", " << incorrect << ")" << endl;
}

int main()
// Runs the tests for Part A
{
   const int n = 5;
   const int m = 7;

   // Seed for random number generator 
   srand(static_cast<unsigned>(time(nullptr)));

   // Random secret code
   code secret(n, m);
   secret.initRandom();

   cout << "Secret code = " << secret << endl;

   // Sample guesses
   code guess_1(n, m);
   code guess_2(n, m);
   code guess_3(n, m);

   vector<int> vector_1 = {5, 0, 3, 2, 6};
   vector<int> vector_2 = {2, 1, 2, 2, 2};
   vector<int> vector_3 = {1, 3, 3, 4, 5};

   if (!guess_1.setCode(vector_1) || !guess_2.setCode(vector_2) || !guess_3.setCode(vector_3))
   {
      cout << "Error: failed to set one of the guess codes." << endl;
      return 1;
   }

   printResult(secret, guess_1);
   printResult(secret, guess_2);
   printResult(secret, guess_3);

   return 0;
} // end of main

// Project 1 Mastermind Part A
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Implementation file for class code. Defines functions and constructor parameters



#include "code.h"
#include <cstdlib>

using namespace std;

code::code(int length, int range)
// Constructor for a code. Initializes code with a length n and digit range m
// Assumes that the length of code is > 0 and that the range is > 0
{
   if ((length <= 0) || (range <= 0))
   {
      cout << "Error: code length and range must be positive." << endl;
      n = 0;
      m = 0;
      nums.clear();
   }
   else
   {
      n = length;
      m = range;
      nums.assign(n, 0);
   }
}

bool code::setCode(const vector<int> &vals)
// Sets nums equal to vals if it is a valid input
// Returns true if vals has length n and all digits are in [0, m - 1]
// Prints an error message and returns false if it doesn't meet the criteria
{
   if (n == 0)
   {
      cout << "Error: code object not initialized." << endl;
      return false;
   }

   if ((int) vals.size() != n)
   {
      cout << "Error: setCode expects " << n
           << " digits, got " << vals.size() << "." << endl;
      return false;
   }

   for (int i = 0; i < n; i++)
   {
      if ((vals[i] < 0) || (vals[i] >= m))
      {
         cout << "Error: digit out of range at index " << i << "." << endl;
         return false;
      }
   }

   nums = vals;
   return true;
}

void code::initRandom()
// Initializes nums randomly using the range [0, m - 1].
// Assumes srand(...) has already been called.
{
   if ((n == 0) || (m == 0))
   {
      cout << "Error: code object not initialized." << endl;
      return;
   }

   for (int i = 0; i < n; i++)
   {
      nums[i] = rand() % m;
   }
}

int code::checkCorrect(const code &guess) const
// Returns the number of digits that are the correct value and in the correct
// position
// Assumes guess has same n and m as the secret code; prints an error and returns 0 otherwise.
{
   if ((guess.n != n) || (guess.m != m))
   {
      cout << "Error: guess has different length or range." << endl;
      return 0;
   }

   int correct = 0;

   for (int i = 0; i < n; i++)
   {
      if (nums[i] == guess.nums[i])
      {
         correct++;
      }
   }

   return correct;
}//end of checkCorrect Function

int code::checkIncorrect(const code &guess) const
// Returns the number of digits that are the right value but in the wrong
// position
// Digits are not counted more than once; exact matches are excluded to avoid double
//counting
// Assumes guess has same n and m and the code is a valid input 
{
   vector<bool> usedInSecret(n, false);
   vector<bool> usedInGuess(n, false);

   // Mark exact matches first so they are not counted as incorrect
   for (int i = 0; i < n; i++)
   {
      if (nums[i] == guess.nums[i])
      {
         usedInSecret[i] = true;
         usedInGuess[i] = true;
      }
   }

   int incorrect = 0;

   // For each unused guess digit, searches for a matching unused digit in the secret code
   for (int i = 0; i < n; i++)
   {
      if (usedInGuess[i])
      {
         continue;
      }

      for (int j = 0; j < n; j++)
      {
         if (!usedInSecret[j] && (guess.nums[i] == nums[j]))
         {
            usedInSecret[j] = true;
            usedInGuess[i] = true;
            incorrect++;
            break;
         }
      }
   }

   return incorrect;
}//end of checkIncorrect Function

void code::print(ostream &ostr) const
// Formats the code and prints it in the form (d0, d1, ..., dn-1)
//uses a for loop to iterate through the code
{
   ostr << "(";

   for (int i = 0; i < n; i++)
   {
      ostr << nums[i];

      if (i < n - 1)
      {
         ostr << ", ";
      }
   }

   ostr << ")";
}

ostream& operator<< (ostream &ostr, const code &c)
// Output operator for code
//uses operator overloading for <<
{
   c.print(ostr);
   return ostr;
}




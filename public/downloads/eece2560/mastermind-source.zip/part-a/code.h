// Project 1 Mastermind Part A
// Group #9
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Header file for the class code 
// Declares all constructors and functions and instantiates private variables
//


#ifndef CODE_H
#define CODE_H


#include <iostream>
#include <vector>

class code
//Our class code stores our Mastermind Code and stores the actual
//digits of our code as well as its length and allowable digit range 
//our class also provides multipule operations we can perform on a code
//allowing us to compare it in multipule ways to our user guess 
{
private:
   std::vector<int> nums;    
   int n;                   
   int m;                    

public:
   code(int length, int range);
   // Constructor to initialize our code length n and digit range [0, m - 1]
   // We assume that length > 0 and range > 0

   bool setCode(const std::vector<int> &vals);
   // Sets nums equal to vals if the given input is valid
   // Returns true if vals has length n and all digits are in [0, m - 1]
   // Otherwise we print an error message and return false

   void initRandom();
   // Initializes a random int randomly in range [0, m - 1]
   // We assume srand() has already been called

   int checkCorrect(const code &guess) const;
   // Returns the number of digits that are the right digit in the right
   // location when comparing Mastermind to our user guess 
   // We assume user guess has same n and m as our Mastermind code
   // It will print error and return 0 otherwise

   int checkIncorrect(const code &guess) const;
   // Returns the number of digits that are the right digit in the wrong
   // location when comparing Mastermind to our user guess 
   // Digits are not counted more than once and exact matches are excluded
   // We assume user guess has same n and m as our Mastermind code 
   // It will print error and return 0 otherwise

   void print(std::ostream &ostr) const;
   // Automatically format and print our code in the form (d0, d1, ..., dn-1)

   friend std::ostream& operator<< (std::ostream &ostr, const code &c);
   //non member function opeartor that is allowed to access private members 
};

std::ostream& operator<< (std::ostream &ostr, const code &c);
// Function decleration prototype for << operator 

#endif

EECE 2560 — mastermind (Parts A and B)

SOURCE REVIEW STATUS — 2026-10-25
These C++ submissions were read, not compiled or executed during the portfolio
update. No configured C++ compiler was available. The supplied prebuilt binaries
were not run or included. Website checks and input-format checks do not validate
the C++ implementation.

TEAM CONTRIBUTION
The original headers credit a four-person team including Arefin Mahmood.
Arefin confirmed that the team worked together on implementation and testing.
No exclusive file/function ownership is inferred. Original source author credits
are retained. Shared matrix/exception support and supplied datasets are included
as dependencies/inputs, not claimed as Arefin's original library or dataset.

CONTENTS
Parts A and B are grouped here as stages of one assignment. Source and text inputs
are byte-for-byte copies. Editor settings, AppleDouble/__MACOSX metadata, .DS_Store,
and compiled executables are excluded. No report PDFs were supplied.

SUGGESTED BUILD COMMANDS — NOT RUN HERE
Run each command from its corresponding directory with a C++17 toolchain.
part-a: g++ -std=c++17 code.cpp main.cpp -o mastermind-a
part-b: g++ -std=c++17 code.cpp response.cpp mastermind.cpp main.cpp -o mastermind-b
Case matters for Card/Deck/Flip/Main filenames. Keep data files in the working
directory or supply explicit paths when prompted. Legacy d_except.h uses strstream.

KNOWN REVIEW NOTES
The game prints its secret for submission/debugging. Interactive EOF handling and incompatible code sizes need further tests. No passing gameplay or duplicate-digit test is claimed in this review.

SOURCE PROVENANCE
User-supplied Fund Engineering Algorithms.zip, nested submissions as recorded in
the portfolio's docs/provenance/eece2560.json. Original archive and extractions are
preserved privately. There are no student IDs, emails or machine paths in these
published source/input copies. Existing source comments, including old project-name
copy/paste labels and unverified performance comments, are retained as submitted.

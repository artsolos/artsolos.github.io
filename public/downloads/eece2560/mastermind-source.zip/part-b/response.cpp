// Project 1 Mastermind Part B
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// initializes response and defines each of the functions
// also defines the operator overloading functions


#include "response.h"


response::response(int c, int i)
{
   //Constructor initalizes correct and incorrect
    correct = c;
    incorrect = i;
}

void response::setCorrect(int c)
{
    //Allows us to set correct manually
    correct = c;
}

void response::setIncorrect(int i)
{
    //Allows us to set incorrect manually
    incorrect = i;
}

int response::getCorrect() const
{
    //returns the amount of correct digits in the right spot
    return correct;
}

int response::getIncorrect() const
{
    //returns the amount of correct digits in the wrong spot
    return incorrect;
}

bool operator==(const response &r1, const response &r2)
{
    //allows us to use == with response objects
    return (r1.getCorrect() == r2.getCorrect() &&
            r1.getIncorrect() == r2.getIncorrect());
}

ostream &operator<<(ostream &out, const response &r)
{
    //allows us to format the output for responses
    out << "(correct, incorrect) = ("
        << r.getCorrect() << ", " << r.getIncorrect() << ")";
    return out;
}
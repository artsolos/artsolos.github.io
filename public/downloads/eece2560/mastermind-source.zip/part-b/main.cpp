// Project 1 Mastermind Part B
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Main program for Project Mastermind Part B this initializes the game settings
// Ensures the inputs are valid so the game doesn't crash
// Creates a mastermind object and starts a game

#include "code.h"
#include "mastermind.h"
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <vector>

using namespace std;

static void printResult(const code &secret, const code &guess)
// Prints the guess and our correct and incorrect response
{
   int correct = secret.checkCorrect(guess);
   int incorrect = secret.checkIncorrect(guess);

   cout << "Guess " << guess << " -> (correct value & position, incorrect position) = ("
        << correct << ", " << incorrect << ")" << endl;
}

int main()
//
{
    int n, m;

    cout << "Enter code length n: ";

    //Keeps asking for an input until there is a valid positive integer
    //Prevents the game from initializing with a negative length
    while (!(cin >> n) || n <= 0)
    {
        cin.clear();
        cin.ignore(10000, '\n');
        cout << "Invalid. Enter a positive integer for n: ";
    }

    // Same thing as n but for m. Makes sure user inputs a valid int to generate a range
    cout << "Enter digit range m (positive int, digits will be 0 to m-1): ";
    while (!(cin >> m) || m <= 0)
    {
        cin.clear();
        cin.ignore(10000, '\n');
        cout << "Invalid. Enter a positive integer for m: ";
    }

    //creates the game with user set inputs and runs it
    mastermind game(n, m);
    game.playGame();

    return 0;
}

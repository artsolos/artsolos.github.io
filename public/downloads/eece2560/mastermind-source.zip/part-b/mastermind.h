// Project 1 Mastermind Part B
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Header file to declare mastermind class 
// Class stores the secret code, reads our user input, evaluates responses
// and checks for a win and runs the full game loop 

#ifndef MASTERMIND_H
#define MASTERMIND_H

#include "code.h"
#include "response.h"
#include <iostream>
#include <vector>

using namespace std;


class mastermind
{
// mastermind runs a Mastermind game between the computer (codemaker)
// and a human player (codebreaker).
private:
    code secret;
    int n;
    int m;

public:
    // Default constructor: n = 5, m = 10
    mastermind();

    // Constructor with parameters (read from keyboard in main)
    mastermind(int length, int range);

    // Prints the secret code (required for submission testing)
    void printSecret() const;

    // Reads a human guess from keyboard and returns a code object
    code user_guess() const;

    // Returns the response to a guess (correct and incorrect)
    response get_response(const code &guess) const;

    // True if the response means the code is solved
    bool user_correct(const response &r) const;

    // Runs the whole game loop
    void playGame();
};

#endif
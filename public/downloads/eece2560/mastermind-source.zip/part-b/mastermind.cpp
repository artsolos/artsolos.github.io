// Project 1 Mastermind Part B
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Implements our mastermind class, contains our function definitions
// that run the game and also handles our user input guesses and manages 
// the game loop 

#include "mastermind.h"
#include <cstdlib>  
#include <ctime>    


mastermind::mastermind()
    : secret(5, 10)
{
    //default constructor
    //sets default game settings if user doesn't specify
    //n = 5 and m = 0..9
    n = 5;
    m = 10;
}


mastermind::mastermind(int length, int range)
    : secret(length, range)
{
    //Constructor for user inputs
    //length = num of digits and range is 0 to (range-1)
    n = length;
    m = range;
}


void mastermind::printSecret() const
{
    //Can see our secret code to ensure our code works
    cout << "Secret code = " << secret << endl;
}


code mastermind::user_guess() const
{
    //remprompts user until they enter a valid input
    while (true)
    {
        cout << "Enter " << n << " digits (each between 0 and " << (m - 1)
             << "), separated by spaces (example: 0 1 1 0 1): ";

        vector<int> vals(n);
        bool ok = true;

        for (int i = 0; i < n; i++)
        {
            if (!(cin >> vals[i]))
            {
                // Non-integer input (e.g., 01101 or letters)
                ok = false;
                break;
            }

            if (vals[i] < 0 || vals[i] >= m)
            {
                ok = false;
                break;
            }
        }

        // Clear leftover input on the line
        cin.clear();
        cin.ignore(10000, '\n');

        if (!ok)
        {
            cout << "Invalid input. Please enter "
                 << n << " integers separated by spaces." << endl;
            continue;
        }

        code guess(n, m);
        if (!guess.setCode(vals))
        {
            cout << "Invalid guess. Please try again." << endl;
            continue;
        }

        return guess;
    }
}


response mastermind::get_response(const code &guess) const
{
    //calls the checkCorrect and checkIncorrect method on guess
    //Returns the response
    int c = secret.checkCorrect(guess);
    int i = secret.checkIncorrect(guess);
    return response(c, i);
}


bool mastermind::user_correct(const response &r) const
{
    //Checks if all the digits are correct
    return (r.getCorrect() == n);
}

void mastermind::playGame()
{
    // Seed random generator once per game
    srand(time(0));

    // Initialize secret code randomly
    secret.initRandom();

    // prints the secret
    printSecret();

    // limits the amount of guesses to ensure game ends; 
    const int maxTurns = 10; 
    int turn = 1;
   
    //keeps track of turns
    while (turn <= maxTurns)
    {
        cout << "\nTurn " << turn << " of " << maxTurns << endl;

        code guess = user_guess();
        response r = get_response(guess);

        cout << "Guess " << guess << " -> " << r << endl;

        if (user_correct(r))
        {
            cout << "You win! You broke the code in " << turn << " turns" << endl;
            return;
        }

        turn++;
    }

    //returns end game message if the computer wins and user had to guess too many times
    cout << "\nThe Computer Wins! You could not break the code in" << maxTurns << " turns" << endl;
    cout << "The secret code was " << secret << endl;
}
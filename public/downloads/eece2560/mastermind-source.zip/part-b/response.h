// Project 1 Mastermind Part B
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Declares the the class members of Response
// Sets private variables correct and incorrect
// two main functions per correct and incorrect
// Set to change values and get to return their values
// Operator overloading for == comparisona and cout

#ifndef RESPONSE_H
#define RESPONSE_H

#include <iostream>
using namespace std;


class response
{
// response stores the result of comparing a guess to the secret:
// correct tell the user how many correct digits are in the right position
// incorrect tells the user how many correct digits in the wrong position
private:
    int correct;
    int incorrect;

public:
    response(int c = 0, int i = 0);
    // Constructor - initializes starting values

    void setCorrect(int c);
    void setIncorrect(int i);
    // Allows us to set correct and incorrect manually if need

    int getCorrect() const;
    int getIncorrect() const;
    // allows us to access the values of correct and incorrect despite being private
};

bool operator==(const response &r1, const response &r2);
// Global operator== compares two responses


ostream &operator<<(ostream &out, const response &r);
// Global operator<< prints response nicely

#endif

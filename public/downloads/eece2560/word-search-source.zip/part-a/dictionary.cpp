// Project 3 Word Search Part A
// Group #9
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// dictionary.cpp
// Implements our dictionary class where we have our function definitions 
// for reading and sorting words from a given file using selection sort 
// and binary search 

#include "dictionary.h"

void dictionary::readFile(const string& filename)
{
    // reads words from the given file and stores them in the vector "words"
    ifstream inFile(filename);
    string word;

    // reads each word from the file and stores in our vector
    while (inFile >> word)
        words.push_back(word);
    
    // debug output showing number of total words loaded 
    cout << "Loaded words: " << words.size() << endl;
}

void dictionary::selectionSort()
{
    // Sorts the words vector in ascending (alphabetical) order using
    // the selection sort algorithm
    int n = words.size();

    // loops through each position in the vector
    for (int i = 0; i < n - 1; i++)
    {
        int minIndex = i;

        // finds the smallest word in the remaining unsorted portion
        for (int j = i + 1; j < n; j++)
        {
            if (words[j] < words[minIndex])
                minIndex = j;
        }

        // swaps the current word with the smallest found word
        swap(words[i], words[minIndex]);
    }
} // end selectionSort

int dictionary::binarySearch(const string& target) const
{
    // Searches for the target word in the sorted dictionary using binary search 
    // and returns the index of the word if found and returns -1 if the word is
    // not found
    int left = 0;
    int right = words.size() - 1;

    // continues searching while the search range is valid
    while (left <= right)
    {
        int mid = (left + right) / 2;

        // if target is found, return its index
        if (words[mid] == target)
            return mid;   

        // if target is greater, search the right half
        else if (words[mid] < target)
            left = mid + 1;
        // otherwise, search the left half
        else
            right = mid - 1;
    }

    // target not found
    return -1;  
} // end binarySearch

ostream& operator<<(ostream& out, const dictionary& d)
{
    // overloaded opearator to print the word list 
    for (const string& word : d.words)
    {
        out << word << endl;
    }
    return out;
} 

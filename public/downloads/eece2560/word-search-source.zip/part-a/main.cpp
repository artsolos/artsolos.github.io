// Project 3 Mastermind Part A
// Group #9
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// main.cpp
// This file contains the main entry point of the program.
// It calls the search() function, which handles reading input
// files and executing the word search algorithm.
#include <iostream>

void search();

int main()
{
    // call main search function to run program
    search();

    return 0;
}

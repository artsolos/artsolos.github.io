// Project 3 Mastermind Part A
// Group #9
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// search.cpp
// This file contains the main logic for the word search program.
// It reads the grid and dictionary files, sorts the dictionary,
// and searches for valid words in the grid.
//
// The program checks all starting positions and explores all
// 8 possible directions to form words. Words of length 5 or greater
// are checked using binary search in the dictionary. Matching words
// are printed along with their starting position and dictionary index.
#include <iostream>
#include <set>
#include <string>

#include "dictionary.h"
#include "grid.h"

using namespace std;

void findMatches(const dictionary& dict, const grid& g)
{
    // open output file we will print our ouput to 
    ofstream out("foundwords.txt");
    // Show format 
    out << "word start point (i, j) found_index" << endl;
    // get grid size
    int n = g.size();

    // set to store unique words (avoids duplicates)
    set<string> foundWords;

    // 8 possible directions (up, down, left, right, diagonals)
    int dirs[8][2] = {
        {-1, 0}, {1, 0}, {0, -1}, {0, 1},
        {-1, -1}, {-1, 1}, {1, -1}, {1, 1}
    };

    // loop through every starting position in grid
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            // try all 8 directions from (i, j)
            for (int d = 0; d < 8; d++)
            {
                string word = "";  // build word step by step

                int x = i;
                int y = j;

                // extend word in current direction
                for (int len = 1; len <= n; len++)
                {
                    // add current character to word
                    word += g.get(x, y);

                    if(len >= 5){
                        // search for word in dictionary using binary search if word is longer than or equal to 5 characters
                        int index = dict.binarySearch(word);

                        // only print valid words (length >= 5 and found)
                        if (index != -1)
                        {
                            // check if word already printed
                            if (foundWords.find(word) == foundWords.end())
                            {
                                // print word, starting position, and dictionary index
                                out << word << " "
                                    << "(" << i << ", " << j << ") "
                                    << index << endl;

                                // store word to avoid duplicates
                                foundWords.insert(word);
                            }
                        }

                    }
                    // move to next position in chosen direction
                    x += dirs[d][0];
                    y += dirs[d][1];
                    
                }
            }
        }
    
    }
    // close file 
    out.close();
}

void search()
{
    // create grid and dictionary objects
    grid g;
    dictionary d;

    string gridFile;
    string dictFile;

    // get filenames from user
    cout << "Enter grid file: ";
    cin >> gridFile;

    cout << "Enter dictionary file: ";
    cin >> dictFile;

    // load grid and dictionary from files
    g.readFile(gridFile);
    d.readFile(dictFile);

    // sort dictionary before binary search
    d.selectionSort();

    // find and print matching words
    findMatches(d, g);
}
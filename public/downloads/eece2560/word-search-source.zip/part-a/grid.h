// Project 3 Mastermind Part A
// Group #9
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// grid.h
// Header file for the grid class.
// The grid class stores a 2D matrix of characters read from a file.
// It provides functions to access individual characters and return
// the size of the grid for use in the search algorithm.

#ifndef GRID_H
#define GRID_H

#include <vector>
#include <fstream>
#include <iostream>

using namespace std;

class grid
{
    // grid class stores a 2D character matrix read from a file
private:
    // 2D grid of characters
    vector<vector<char>> mat;  
    // size of grid (n x n)
    int n;                     

public:
    // reads grid from file
    void readFile(const string& filename); 
    // returns character at (i, j) 
    char get(int i, int j) const;      
    // returns grid size     
    int size() const;                       
};

#endif


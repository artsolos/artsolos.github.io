// Project 3 Word Search Part A
// Group #9
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Implements our grid class and contains the function
// definitions for reading a grid from a file, accessing elements
// in the grid and and retrieving the grid size

#include "grid.h"

void grid::readFile(const string& filename)
{
    // reads the grid from a file and stores it in a 2D vector
    // the first value in the file represents the size n of the grid
    // the next n x n values represent the characters in the grid
    ifstream inFile(filename);

    // checks if file opened correctly
    if (!inFile)
    {
        cout << "ERROR: cannot open grid file\n";
    return;
    }

    // reads the grid size
    inFile >> n;

    // debugs output showing grid size
    cout << "Grid size: " << n << endl;

    // resizes matrix to n x n
    mat.resize(n, vector<char>(n));

    // reads each character into the grid
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            inFile >> mat[i][j];
} // end readFile

char grid::get(int i, int j) const
{
    // returns the character at position (i, j) in the grid
    // uses wrap-around indexing so that out of bounds indices
    // wrap back into the grid 

    // wraps the row index
    int r = (i + n) % n;

    // wraps the column index
    int c = (j + n) % n;

    return mat[r][c];
} // end get

int grid::size() const
{
    // returns the size of the grid, # of columns and rows
    return n;
} // end size
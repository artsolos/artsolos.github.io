// Project 3 Mastermind Part B
// Group #9
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// main.cpp
// This file contains the main entry point of the program.
// Prompts the user to select a sorting algorithm and it then calls 
// the search() function, which handles reading input
// files and executing the chosen word search algorithm method 
#include <iostream>

void search(int type);

int main()
{
    int type;

    // prompt user to select sorting method 
    std::cout << "Choose preferred sorting method:\n";
    std::cout << "1 = Selection Sort\n";
    std::cout << "2 = Quick Sort\n";
    std::cout << "3 = Heap Sort\n";
    std::cout << "Enter your method choice: ";
    std::cin >> type;

    // call search function with selected sorting algorithm 
    search(type);

    return 0;
}
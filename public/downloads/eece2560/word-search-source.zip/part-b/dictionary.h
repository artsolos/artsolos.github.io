// Project 3 Word Search Part A
// Group #9
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// dictionary.h
// Header file for our dictionary class which stores a collection of words 
// from a file and allows us to read words from a file into a vector as 
// well as sorting the words using selection sort as well as quicksort and 
// heapsort (Part B) and searching for a word using binary search
// It also allows us to output the dictionary contents

#ifndef DICTIONARY_H
#define DICTIONARY_H

#include <vector>
#include <string>
#include <fstream>
#include <iostream>

using namespace std;

class dictionary
{
    // This class defines a dictionary which stores a list of words
    // and allows reading, sorting, and searching words within that list
private:
    // vector that stores all words from the dictionary file
    vector<string> words;

public:
    // Reads words from a file and stores them in a vector 
    void readFile(const string& filename);

    // Sorts given words in the dictionary using selection sort
    void selectionSort();

    // Performs binary search on the sorted dictionary where 
    // if the word is found it return index and otherwise 
    // if word is not found return -1 
    int binarySearch(const string& target) const;

    // Overloaded << operator which prints all words in dictionary
    friend ostream& operator<<(ostream& out, const dictionary& d);

    // Sorts given words in the dictionary using quick sort
    void quickSort();

    //Sorts given words in the dictionary using heap sort 
    void heapSort();


};

#endif

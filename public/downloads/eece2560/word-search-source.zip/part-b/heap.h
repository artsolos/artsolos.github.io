// Project Word Search Part B
// Group #9
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// heap.h
// Header file for the heap class.
// The heap class stores a collection of strings using a vector-based
// binary max-heap structure. It provides functions to access parent
// and child indices, retrieve elements, and supports building a
// max-heap and performing heap sort.

#ifndef HEAP_H
#define HEAP_H

#include <vector>
#include <string>
using namespace std;

class heap
{
private:
    vector<string> arr;

public:
    // Returns the index of the parent of node i
    int parent(int i);

    // Returns the index of the left child of node i
    int left(int i);

    // Returns the index of the right child of node i
    int right(int i);

    // Returns the item stored at index i
    string getItem(int i);

    // Initializes the heap using the given vector of strings
    void initializeMaxHeap(const vector<string>& data);

    // Restores the max-heap property starting at index i
    void maxHeapify(int i, int n);

    // Builds a max-heap from the current array
    void buildMaxHeap();

    // Sorts the heap contents and returns the sorted vector
    vector<string> heapSort();
};

#endif
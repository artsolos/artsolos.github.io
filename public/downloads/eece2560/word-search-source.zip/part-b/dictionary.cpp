// Project 3 Word Search Part B
// Group #9
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// dictionary.cpp
// Implements our dictionary class where we have our function definitions 
// for reading and sorting words from a given file using selection sort, 
// quicksort, and heapsort as well as performing binary search 
// also includes an overloaded output operator for printing dictionary

#include "dictionary.h"
#include "heap.h"

void dictionary::readFile(const string& filename)
{
    // reads words from the given file and stores them in the vector "words"
    ifstream inFile(filename);
    string word;

    // reads each word from the file and stores in our vector
    while (inFile >> word)
        words.push_back(word);
    
    // debug output showing number of total words loaded 
    cout << "Loaded words: " << words.size() << endl;
}

void dictionary::selectionSort()
{
    // Sorts the words vector in ascending (alphabetical) order using
    // the selection sort algorithm
    int n = words.size();

    // loops through each position in the vector
    for (int i = 0; i < n - 1; i++)
    {
        int minIndex = i;

        // finds the smallest word in the remaining unsorted portion
        for (int j = i + 1; j < n; j++)
        {
            if (words[j] < words[minIndex])
                minIndex = j;
        }

        // swaps the current word with the smallest found word
        swap(words[i], words[minIndex]);
    }
} // end selectionSort

int dictionary::binarySearch(const string& target) const
{
    // Searches for the target word in the sorted dictionary using binary search 
    // and returns the index of the word if found and returns -1 if the word is
    // not found
    int left = 0;
    int right = words.size() - 1;

    // continues searching while the search range is valid
    while (left <= right)
    {
        int mid = (left + right) / 2;

        // if target is found, return its index
        if (words[mid] == target)
            return mid;   

        // if target is greater, search the right half
        else if (words[mid] < target)
            left = mid + 1;
        // otherwise, search the left half
        else
            right = mid - 1;
    }

    // target not found
    return -1;  
} // end binarySearch


int partition(vector<string>& arr, int low, int high)
{
    // This function partitions the array around a pivot element 
    // (last element) and elements smaller than the pivot are moved 
    // to the left side, and elements greater than the pivot are moved
    // to the right side. It then returns the final index position of 
    // the pivot after partitioning
    string pivot = arr[high];
    int i = low - 1;

    //iterates throught the array and compares each element to the pivot 
    for (int j = low; j < high; j++)
    {
        //if current element is smaller than pivot then swap 
        if (arr[j] < pivot)
        {
            i++;
            swap(arr[i], arr[j]);
        }
    }

    //place pivot at its correct sorted position 
    swap(arr[i + 1], arr[high]);
    return i + 1;
}


void quickSortHelper(vector<string>& arr, int low, int high)
{
    // This recursively sorts our array using the quicksort algorithm
    // by partitioning the given array before then sorting the left and 
    // right subarrays

    // are base case is only sort if there are at least 2 elements 
    if (low < high)
    {
        //partition the array get our pivot index 
        int pi = partition(arr, low, high);

        // recuresvily sorts the element before the pivot 
        quickSortHelper(arr, low, pi - 1);

        // recursively sort elements after pivot
        quickSortHelper(arr, pi + 1, high);
    }
}


void dictionary::quickSort()
{
    // sorts the words vector using the quicksort algorithm 
    // in order to perform the sorting on the entire vector 
    // this function calls the recursive quickSortHelper function
    quickSortHelper(words, 0, words.size() - 1);
}


void dictionary::heapSort()
{
    // sorts the words vector using the heapsort algorithm and 
    // a heap object is created and initialized with the current words
    // the heapSort function returns a sorted vector, which replaces
    // the original words vector
    heap h;

    // initialize heap with current words and build max heap
    h.initializeMaxHeap(words);

    // perform heapsort and store sorted result back into words
    words = h.heapSort();
}

ostream& operator<<(ostream& out, const dictionary& d)
{
    // overloaded opearator to print the word list 
    for (const string& word : d.words)
    {
        out << word << endl;
    }
    return out;
} 

// Project Word Search Part B
// Group #9
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// heap.cpp
// Implementation file for the heap class.
// This file defines the functionality of the heap, including helper
// functions for navigating the heap, maintaining the max-heap property,
// building the heap, and performing heap sort on a vector of strings.

#include "heap.h"


int heap::parent(int i)
{
    // Returns the index of the parent node
    return (i - 1) / 2;
}


int heap::left(int i)
{
    // Returns the index of the left child
    return 2 * i + 1;
}


int heap::right(int i)
{
    // Returns the index of the right child
    return 2 * i + 2;
}


string heap::getItem(int i)
{
    // Returns the string stored at index i
    return arr[i];
}


void heap::initializeMaxHeap(const vector<string>& data)
{
    // Initializes the heap with input data and builds a max-heap
    // Copy the input vector into the heap array
    arr = data;

    // Build the max-heap structure from the input data
    buildMaxHeap();
}


void heap::maxHeapify(int i, int n)
{
    // Maintains the max-heap property for the subtree rooted at index i
    // Store the current node as the largest initially
    int largest = i;
    int l = left(i);
    int r = right(i);

    // Compare the left child with the current largest value
    if (l < n && arr[l] > arr[largest])
        largest = l;

    // Compare the right child with the current largest value
    if (r < n && arr[r] > arr[largest])
        largest = r;

    // If a larger child was found, swap and continue heapifying
    if (largest != i)
    {
        swap(arr[i], arr[largest]);
        maxHeapify(largest, n);
    }
}


void heap::buildMaxHeap()
{
    // Builds a max-heap from the array
    // Start from the last non-leaf node and heapify each subtree
    int n = arr.size();
    for (int i = n / 2 - 1; i >= 0; i--)
        maxHeapify(i, n);
}


vector<string> heap::heapSort()
{
    // Sorts the array using heap sort and returns the sorted vector
    // Build a max-heap before sorting
    int n = arr.size();
    buildMaxHeap();

    
    for (int i = n - 1; i > 0; i--)
    {
        // Repeatedly move the largest element to the end of the array
        swap(arr[0], arr[i]);
        maxHeapify(0, i);
    }

    // Return the sorted array
    return arr;
}
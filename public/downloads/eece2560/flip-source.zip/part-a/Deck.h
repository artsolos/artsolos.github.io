// Project 2 Mastermind Part A
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Header file for the Deck class, a Deck stores between 0 and 52 cards in a 
// linked list. The deck has a pointer front to the first node or "card". 
// Class also supports printing and shuffling

#ifndef DECK_H
#define DECK_H

#include <iostream>
#include "Card.h"

using namespace std;

class Deck
{
public:
   // Constructs a standard 52-card deck in order:
   // ace-king for each suit, suit order: club, diamond, heart, spade.
   Deck();
   
   // Copy constructor. Creates a deep copy of other.
   Deck(const Deck& other);
   
   // Assignment operator. Deep-copies other into this deck.
   Deck& operator=(const Deck& other);

   // Destructor. Frees all nodes.
   ~Deck();

   // Shuffles the deck into a random order. Mimics real life shuffling
   void shuffle();
   
   // Prints all cards in the deck from front to end, one per line.
   // Uses overloading to format the output
   friend ostream& operator<<(ostream& os, const Deck& d);

private:
   struct Node
   {
      Card card;
      Node* next;
   }; // end struct

   //instantiates the front node
   Node* front;

   // Deletes all nodes and sets front to NULL.
   void clear();
   
   // Adds a new node containing card c to the end of the list.
   void appendNode(const Card& c);
   
   // Returns the number of nodes in the list.
   int length() const;
   
};

#endif



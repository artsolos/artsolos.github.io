// Project 2 Mastermind Part A
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Implementation file for the Card class. Ensures everything in the header file functions properly

#include "Card.h"

using namespace std;

Card::Card(int v, const string& s)
{
   //defines card and sets its value and suit
   value = v;
   suit = s;
} // end Card

void Card::setValue(int v)
{
   //Allows us to change the value of the card
   value = v;
} // end setValue

void Card::setSuit(const string& s)
{
   //Allows us to change the suit of the card
   suit = s;
} // end setSuit

int Card::getValue() const
{
   //Gets the value of the card
   return value;
} // end getValue

string Card::getSuit() const
{
   //Gets the suit of the card
   return suit;
} // end getSuit

string Card::valueToString() const
{
   //Helps decode values that don't literally correspond to cards
   //if value is 1 it is an ace
   //if value is an 11 it is a jack, 12 a queen, and 13 a king
   //Otherwise we just return the integer as a string cause there is a corresponding card
   if (value == 1)
   {
      return "Ace";
   }
   else if (value == 11)
   {
      return "Jack";
   }
   else if (value == 12)
   {
      return "Queen";
   }
   else if (value == 13)
   {
      return "King";
   }
   else
   {
      return to_string(value);
   } // end if
} // end valueToString

ostream& operator<<(ostream& os, const Card& c)
{
   //Overloads the << operator
   //Edits output for Card so that it prints it in our desired fromat
   os << c.valueToString() << " of " << c.suit;
   return os;
} // end operator<<

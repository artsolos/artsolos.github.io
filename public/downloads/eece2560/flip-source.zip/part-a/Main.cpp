// Project 2 Mastermind Part A
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Our main program file for Project Flip Part A. Creates an ordered deck,
// prints it for the user, shuffles once before then printing it again for 
// the user using our previously defined header and implementation files 

#include "Deck.h"
#include <iostream>

using namespace std;

int main()
{
   Deck deck;

   cout << "Preshuffled Deck:" << endl;
   cout << deck << endl;

   deck.shuffle();

   cout << "Deck shuffled:" << endl;
   cout << deck << endl;

   return 0;
} // end main

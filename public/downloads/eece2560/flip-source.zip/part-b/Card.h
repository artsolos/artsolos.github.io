// Project 2 Mastermind Part B
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Header file for the Card class, where a card stores a value between 1 and 13 
// and a suit (Club, Diamond, Heart, Spade). It also provides an overloaded << 
// operator for printing 

#ifndef CARD_H
#define CARD_H

#include <iostream>
#include <string>

using namespace std;

//Defines A Card. It contains a value and suit. Includes various functions to get the value and suit
class Card
{
public:
   // Constructs a Card with value v and suit s.
   // Assumes v is in [1, 13] and s is a valid suit string.
   Card(int v = 1, const string& s = "Club");
   
   // Sets the value of this card to v.
   // Assumes v is in [1, 13].
   void setValue(int v);

   // Sets the suit of this card to s.
   // Assumes s is a valid suit included in "Club", "Diamond", "Heart", or "Spade".
   void setSuit(const string& s);
   
   // Returns the value of the card.
   int getValue() const;
   
   // Returns the suit of the card.
   string getSuit() const;
   
   // Returns "Ace", "Jack", "Queen", "King", or the number as a string. Helps with decoding card values above 10
   string valueToString() const;
   
   // Prints the card in the form "<Value> of <Suit>". 
   friend ostream& operator<<(ostream& os, const Card& c);

   // Copy constructor
   // This creates a new Card object which is a copy of diffirent Card 
   Card(const Card& other);

   // Assignment operator
   // This copies the value and suit from another Card into this Card
   Card& operator=(const Card& other);
   

private:
   int value;
   string suit;
};

#endif



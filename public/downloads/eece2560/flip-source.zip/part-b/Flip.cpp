// Project 2 Mastermind Part B
// Group #9
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// This file defines the playFlip() function for the flip card game,
// the function creates a deck, shuffles it, and deals 24 cards face down
// into a hand deck. The player may repeatedly choose to flip the next card
// or end the game. Each flipped card updates the player's score based on
// the game rules. The game ends when the player chooses to stop or when
// there are no more cards left in the hand deck

#include <iostream>
#include "Deck.h"
#include "Flip.h"
using namespace std;

void playFlip()
{
   Deck deck;

   deck.shuffle();

   cout << "Shuffled deck:" << endl;
   cout << deck << endl;

   // create an empty hand deck
   Deck hand(true);

   
   for (int i = 0; i < 24; ++i)
   {
      // move the first 24 cards from the deck to the player's hand
      Deck::Node* card = deck.deal();
      hand.replace(card);
   }

   cout << "Hand deck:" << endl;
   cout << hand << endl;

   // print out remaining cards in the deck after hand
   cout << "Remaining deck:" << endl;
   cout << deck << endl;

   cout << "24 cards have been placed face down" << endl;

   // variable to keep track of the player's score
   int score = 0;

   cout << "Starting Flip Game:" << endl;

   while (true)
   {
      char choice;

      cout << "Flip a card or end the game? (f/e): ";
      cin >> choice;

      if (choice == 'e')
      {
         cout << "Game ended" << endl;
         cout << "Final score: " << score << endl;
         break;
      }

      if (choice != 'f')
      {
         cout << "Invalid input. Please enter f(flip) or e(end)" << endl;
         continue;
      }

      // deal the next card from the hand
      Deck::Node* flipped = hand.deal();

      if (flipped == NULL)
      {
         cout << "No more cards in the deck!!" << endl;
         cout << "Your final score is: " << score << endl;
         break;
      }

      cout << "Flipped: " << flipped->card << endl;

      int value = flipped->card.getValue();
      string suit = flipped->card.getSuit();

      // apply scoring rules based on card value
      if (value == 1)
      {
         score += 10;   
      }
      else if (value >= 11 && value <= 13)
      {
         score += 5;    
      }
      else if (value >= 8 && value <= 10)
      {
         // 8, 9, 10 give 0 points
      }
      else if (value == 7)
      {
         score /= 2;   
      }
      else
      {
         score = 0;     
      }

      
      if (suit == "Hearts")
      {
         // hearts give one extra point
         score += 1;
      }

      cout << "Score: " << score << endl;

      // delete the flipped card node
      delete flipped;
   }
}

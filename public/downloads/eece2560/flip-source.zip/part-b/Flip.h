// Project 2 Mastermind Part B
// Group #9
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Flip.h
// This header file declares the playFlip() function.
// The playFlip() function contains the main logic for the Flip card game,
// where cards are flipped from a until a user decides to stop
// the user aims to get the highest score
// It incorporates the functions we previously designed. 

#ifndef FLIP_H
#define FLIP_H

// Runs the Flip card game.
// The implementation of this function is defined in Flip.cpp.
void playFlip();

#endif
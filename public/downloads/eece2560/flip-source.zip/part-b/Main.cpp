// Project 2 Mastermind Part B
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Our main program file for Project Flip Part B
#include "Flip.h"
#include "Deck.h"
#include <iostream>

using namespace std;

int main()
{
   playFlip();
   return 0;
} // end main

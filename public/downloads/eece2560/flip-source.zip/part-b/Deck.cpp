// Project 2 Mastermind Part B
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Our implementation file for the Deck class

#include "Deck.h"
#include <vector>
#include <algorithm>
#include <random>

using namespace std;

Deck::Deck()
{
   //initalizes our front to NULL and creates our 52 card deck in order 
   //does this by adding each card to our linked list using appendNode()
   front = NULL;

   string suits[4] = {"Clubs", "Diamonds", "Hearts", "Spades"};
   // Creates our standard 52-card deck in suit and major order 
   for (int s = 0; s < 4; ++s)
   {
      for (int v = 1; v <= 13; ++v)
      {
      appendNode(Card(v, suits[s]));
      } // end for
   }
}// end Deck

Deck::Deck(const Deck& other)
{
    //creates a deep copy of the deck in order to avoid memory corruption 
   front = NULL;

   Node* cur = other.front;
   while (cur != NULL)
   {
      appendNode(cur->card);
      cur = cur->next;
   } // end while
} // end Deck

Deck& Deck::operator=(const Deck& other)
{
    //Handles assigment by preventing self assigment and deletes current deck
    //contents copies the nodes and returns *this
   if (this != &other)
   {
      clear();

      Node* cur = other.front;
      while (cur != NULL)
      {
         appendNode(cur->card);
         cur = cur->next;
      } // end while
   } // end if

   return *this;
} // end operator=

Deck::~Deck()
{
    //frees dynamically allocated memory  
   clear();
} // end ~Deck

void Deck::clear()
{
    //Deletes every node in the linked list, starts at front and steps 
    //through each node deleting it and sets front to NULL
   Node* cur = front;

   while (cur != NULL)
   {
      Node* temp = cur;
      cur = cur->next;
      delete temp;
   } // end while

   front = NULL;
} // end clear

void Deck::appendNode(const Card& c)
{
    //Adds a new node card c to the end of the linked list 
   Node* newPtr = new Node;
   newPtr->card = c;
   newPtr->next = NULL;

   if (front == NULL)
   {
      front = newPtr;
   }
   else
   {
      Node* cur = front;
      while (cur->next != NULL)
      {
         cur = cur->next;
      } // end while

      cur->next = newPtr;
   } // end if
} // end appendNode

int Deck::length() const
{
    //Counts number of nodes, stepping through the list and incrementing count 
   int count = 0;
   Node* cur = front;

   while (cur != NULL)
   {
      ++count;
      cur = cur->next;
   } // end while

   return count;
} // end length

void Deck::shuffle()
{
    //Randomizes the order of the "cards in the deck" or nodes in the linked list
    //We do this by copying the linked list into a vector which we can shuffle much
    //easier directly using a C++ random engine before then copying the shuffled 
    //values back into the linked list 
   vector<Card> cards;
   cards.reserve(length());

   Node* cur = front;

   while (cur != NULL)
   {
      cards.push_back(cur->card);
      cur = cur->next;
   } // end while

   random_device rd;
   mt19937 gen(rd());

   std::shuffle(cards.begin(), cards.end(), gen);

   cur = front;
   int i = 0;

   while (cur != NULL)
   {
      cur->card = cards[i];
      ++i;
      cur = cur->next;
   } // end while
} // end shuffle

ostream& operator<<(ostream& os, const Deck& d)
{
    //steps through linked list and prints using the card classes 
    // overloaded operator <<
   Deck::Node* cur = d.front;

   while (cur != NULL)
   {
      os << cur->card << endl;
      cur = cur->next;
   } // end while

   return os;
} // end operator<<


Deck::Node* Deck::deal()
{
   // This removes the node which is the top card in the deck and returns
   // a pointer to that node, if the deck is empty it will return NULL
   if (front == NULL)
   {
      return NULL;
   }

   Node* temp = front;
   front = front->next;

   temp->next = NULL;

   return temp;
}


void Deck::replace(Node* cardNode)
{
   // This inserts the given card node at the bottom of the deck and if the
   // deck is empty the card then become the first node 
   if (cardNode == NULL)
   {
      return;
   }

   cardNode->next = NULL;

   if (front == NULL)
   {
      front = cardNode;
      return;
   }

   Node* cur = front;

   while (cur->next != NULL)
   {
      cur = cur->next;
   }

   cur->next = cardNode;
}

Deck::Deck(bool empty)
{
   // Constructor for an empty deck with an input of empty parameter 
   // so we know to initialize the deck with no cards 
   front = NULL;
}

// Project #4 Mastermind Part B
// Group #9
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// board.cpp
// Implementation file for the board class.
// This class represents a Sudoku board and provides functionality
// for initializing, modifying, validating, and solving the puzzle.
// The implementation uses optimized conflict tracking to allow
// constant-time validity checks and an MRV heuristic for solving.

#include "board.h"


board::board(int sqSize)
    : value(BoardSize + 1, BoardSize + 1),
      rowCheck(BoardSize + 1, BoardSize + 1, false),
      colCheck(BoardSize + 1, BoardSize + 1, false),
      squareCheck(BoardSize + 1, BoardSize + 1, false)
{
    // Initializes the board and tracking arrays.
    // sqSize: size of each sub-square (e.g., 3 for a 9x9 board)
    // Assumes BoardSize and SquareSize are already defined.
    clear();
}

void board::clear()
{
    // Resets the entire board to blank and clears all conflict trackers.
    // No parameters.
    // Assumes board size is valid.

    // Set all cells to blank
    for (int i = 1; i <= BoardSize; i++)
        for (int j = 1; j <= BoardSize; j++)
            value[i][j] = Blank;

    // Reset tracking arrays
    for (int i = 1; i <= BoardSize; i++)
        for (int j = 1; j <= BoardSize; j++)
        {
            rowCheck[i][j]    = false;
            colCheck[i][j]    = false;
            squareCheck[i][j] = false;
        }
}

void board::initialize(ifstream &fin)
{
    // Reads a Sudoku board from input file and populates it.
    // fin: input file stream containing board data.
    // Assumes file format uses '.' for blanks.
    char ch;

    clear();

    // Read board values row by row
    for (int i = 1; i <= BoardSize; i++)
        for (int j = 1; j <= BoardSize; j++)
        {
            fin >> ch;

            if (ch != '.')
                setCell(i, j, ch - '0');
        }
}


int board::squareNumber(int i, int j)
{
    // Computes which sub-square a given cell belongs to.
    // i, j: row and column indices.
    // Returns: square index (1-based).
    return SquareSize * ((i - 1) / SquareSize)
         + (j - 1) / SquareSize + 1;
}


ValueType board::getCell(int i, int j)
{
    // Returns the value at a given position.
    // i, j: row and column indices.
    // Throws error if indices are out of bounds.
    if (i >= 1 && i <= BoardSize && j >= 1 && j <= BoardSize)
        return value[i][j];
    else
        throw rangeError("bad value in getCell");
}

bool board::isBlank(int i, int j)
{
    // Checks if a given cell is empty.
    // i, j: row and column indices.
    // Returns true if blank, false otherwise.
    return (getCell(i, j) == Blank);
}

void board::setCell(int i, int j, int val)
{
    // Assigns a value to a specific cell and updates trackers.
    // i, j: row and column indices.
    // val: value to insert.
    // Assumes val is within valid Sudoku range.
    if (i < 1 || i > BoardSize || j < 1 || j > BoardSize)
        throw rangeError("bad index in setCell");

    if (val < MinValue || val > MaxValue)
        throw rangeError("bad value in setCell");

    value[i][j] = val;

    // Update conflict tracking incrementally
    int sq = squareNumber(i, j);

    rowCheck[i][val]     = true;
    colCheck[j][val]     = true;
    squareCheck[sq][val] = true;
}


void board::clearCell(int i, int j)
{
    // Removes a value from a cell and updates trackers.
    // i, j: row and column indices.
    // Assumes indices are valid.
    if (i < 1 || i > BoardSize || j < 1 || j > BoardSize)
        throw rangeError("bad index in clearCell");

    int val = value[i][j];

    // If already blank, do nothing
    if (val == Blank)
        return;

    int sq = squareNumber(i, j);

    // Remove from tracking arrays incrementally
    rowCheck[i][val]     = false;
    colCheck[j][val]     = false;
    squareCheck[sq][val] = false;

    value[i][j] = Blank;
}

void board::updateConflicts()
{
    // Rebuilds all conflict tracking arrays from scratch.
    // Used for compatibility but not in the main solving path.

    // Reset all trackers
    for (int i = 1; i <= BoardSize; i++)
        for (int j = 1; j <= BoardSize; j++)
        {
            rowCheck[i][j]    = false;
            colCheck[i][j]    = false;
            squareCheck[i][j] = false;
        }

    // Recompute conflicts from current board state
    for (int i = 1; i <= BoardSize; i++)
        for (int j = 1; j <= BoardSize; j++)
            if (!isBlank(i, j))
            {
                int val = value[i][j];
                int sq  = squareNumber(i, j);

                rowCheck[i][val]     = true;
                colCheck[j][val]     = true;
                squareCheck[sq][val] = true;
            }
}

void board::print()
{
    // Prints the Sudoku board with grid formatting.
    // Draws horizontal and vertical separators between 3x3 squares.
    for (int i = 1; i <= BoardSize; i++)
    {
        // Print horizontal separator between squares
        if ((i - 1) % SquareSize == 0)
        {
            cout << " -";
            for (int j = 1; j <= BoardSize; j++)
                cout << "---";
            cout << "-\n";
        }

        for (int j = 1; j <= BoardSize; j++)
        {
            // Print vertical separator between squares
            if ((j - 1) % SquareSize == 0)
                cout << "|";

            if (!isBlank(i, j))
                cout << " " << getCell(i, j) << " ";
            else
                cout << "   ";
        }
        cout << "|\n";
    }

    // Print bottom border
    cout << " -";
    for (int j = 1; j <= BoardSize; j++)
        cout << "---";
    cout << "-\n";
}


void board::printConflicts()
{
    // Outputs any missing values per row for conflict checking.
    // Useful for debugging and Part A verification.
    cout << "\nConflict Check:\n";

    for (int i = 1; i <= BoardSize; i++)
        for (int val = 1; val <= BoardSize; val++)
            if (!rowCheck[i][val])
                cout << "Row " << i << " missing " << val << endl;
}


bool board::isSolved()
{
    // Checks if the board is fully and correctly solved.
    // Returns true if every row, column, and square contains all digits.
    for (int i = 1; i <= BoardSize; i++)
        for (int val = 1; val <= BoardSize; val++)
            if (!rowCheck[i][val] || !colCheck[i][val] || !squareCheck[i][val])
                return false;

    cout << "Board is solved!\n";
    return true;
}


bool board::findBlank(int &row, int &col)
{
    // Locates the next blank cell to fill using the MRV heuristic.
    // Picks the blank cell with the fewest remaining legal values,
    // which reduces the search tree and minimizes recursive calls.
    // row, col: set to the position of the best blank cell found.
    // Returns true if a blank cell exists, false if board is complete.
    int bestCount = MaxValue + 1;
    bool found    = false;

    for (int i = 1; i <= BoardSize; i++)
    {
        for (int j = 1; j <= BoardSize; j++)
        {
            if (!isBlank(i, j)) continue;

            // Count how many values are still legal for this cell
            int sq    = squareNumber(i, j);
            int count = 0;

            for (int v = MinValue; v <= MaxValue; v++)
                if (!rowCheck[i][v] && !colCheck[j][v] && !squareCheck[sq][v])
                    count++;

            if (count < bestCount)
            {
                bestCount = count;
                row       = i;
                col       = j;
                found     = true;

                // Can't do better than 1 legal value — stop scanning early
                if (bestCount == 1) return true;
            }
        }
    }

    return found;
}


bool board::isValid(int row, int col, int val)
{
    // Checks if placing a value at a cell is valid using O(1) lookup.
    // row, col: target position.
    // val: value to check.
    // Returns true if the value does not conflict with row, column, or square.
    int sq = squareNumber(row, col);

    return !rowCheck[row][val]
        && !colCheck[col][val]
        && !squareCheck[sq][val];
}


bool board::solve()
{
    // Initializes the recursive solving process.
    // Resets recursive call counter before starting.
    // Returns true if a solution is found.
    recursiveCalls = 0;
    return solveRecursive();
}


bool board::solveRecursive()
{
    // Recursive backtracking solver using MRV heuristic.
    // Tries each legal value for the most constrained blank cell.
    // Backtracks if no valid value leads to a solution.
    // Returns true if the board is solved from the current state.
    recursiveCalls++;

    int row, col;

    // If no blank cells remain, the puzzle is solved
    if (!findBlank(row, col))
        return true;

    int sq = squareNumber(row, col);

    // Try all possible values for this cell
    for (int val = MinValue; val <= MaxValue; val++)
    {
        // Use tracking arrays for O(1) validity check
        if (!rowCheck[row][val]
         && !colCheck[col][val]
         && !squareCheck[sq][val])
        {
            setCell(row, col, val);

            if (solveRecursive())
                return true;

            // Backtrack
            clearCell(row, col);
        }
    }

    // No valid value found — trigger backtrack
    return false;
}


int board::getRecursiveCalls()
{
    // Returns the total number of recursive calls made during solving.
    return recursiveCalls;
}
// Project#4 Sudoku Part B
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Reads Sudoku boards from a specified file by the user
// Then solves each board using recursion and backtracking
// Prints the solved board and recursive call statistics

#include <iostream>
#include <fstream>
#include "board.h"

using namespace std;

int main()
{
    ifstream fin;
    string fileName;

    // Prompt user for input file
    cout << "Enter input file name: ";
    cin >> fileName;

    // Open the file
    fin.open(fileName.c_str());

    // Check if file opened successfully
    if (!fin)
    {
        cerr << "Cannot open " << fileName << endl;
        return 1;
    }

    try
    {
        // Create Sudoku board object
        board b(SquareSize);

        // Track total recursive calls and number of boards
        int totalCalls = 0;
        int boardCount = 0;
        
        while (fin && fin.peek() != 'Z')
        {
            // Process boards until sentinel 'Z' is reached
            // Initialize board from file
            b.initialize(fin);

            cout << "\nOriginal Board:\n";
            b.print();

            // Solve the board
            if (b.solve())
            {
                cout << "\nSolved Board:\n";
                b.print();
            }
            else
            {
                cout << "No solution found.\n";
            }

            // Get recursive call count
            int calls = b.getRecursiveCalls();
            cout << "Recursive calls: " << calls << endl;

            totalCalls += calls;
            boardCount++;
        }
        // Print total and average recursive calls
        cout << "\nTotal recursive calls: " << totalCalls << endl;

        if (boardCount > 0)
        {
            cout << "Average recursive calls: "
                << (double)totalCalls / boardCount << endl;
        }
    }

    catch (indexRangeError &ex)
    {
        // Catch and display any index errors
        cout << ex.what() << endl;
    }

    return 0;
}
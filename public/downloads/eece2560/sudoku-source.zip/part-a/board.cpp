// Project 4 Mastermind Part A
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Implementation file for the board class.
// This file defines the functionality for representing and managing a Sudoku board.
// It includes methods for initializing the board, setting and clearing cell values,
// and maintaining constraint tracking using row, column, and subgrid checks.
// It also provides helper functions for accessing cell values, printing the board,
// and determining whether the board is solved.

#include "board.h"

board::board(int sqSize)
    : value(BoardSize + 1, BoardSize + 1),
      rowCheck(BoardSize + 1, BoardSize + 1, false),
      colCheck(BoardSize + 1, BoardSize + 1, false),
      squareCheck(BoardSize + 1, BoardSize + 1, false)
{
    // Constructor
    // Initialize the board by clearing all values
    clear();
}


void board::clear()
{
    // Clear board
    // Set every cell in the board to Blank
    for (int i = 1; i <= BoardSize; i++)
        for (int j = 1; j <= BoardSize; j++)
            value[i][j] = Blank;

    // Recalculate constraint tracking arrays
    updateConflicts();
}


void board::initialize(ifstream &fin)
{
    // Initialize from file
    char ch;

    // Start with an empty board
    clear();

    // Read values from file and populate board
    for (int i = 1; i <= BoardSize; i++)
    {
        for (int j = 1; j <= BoardSize; j++)
        {
            fin >> ch;

            // If not blank, convert char to int and set cell
            if (ch != '.')
                setCell(i, j, ch - '0');
        }
    }
}


int board::squareNumber(int i, int j)
{
    // Square number
    // Compute which sub-square (1–9) the cell belongs to
    return SquareSize * ((i - 1) / SquareSize) + (j - 1) / SquareSize + 1;
}


ValueType board::getCell(int i, int j)
{
    // Get cell
    // Validate indices are within bounds
    if (i >= 1 && i <= BoardSize && j >= 1 && j <= BoardSize)
        return value[i][j];
    else
        throw rangeError("bad value in getCell");
}


bool board::isBlank(int i, int j)
{
    // Check blank
    // A cell is blank if it equals the Blank constant
    return (getCell(i, j) == Blank);
}


void board::setCell(int i, int j, int val)
{
    // Set cell
    // Validate indices
    if (i < 1 || i > BoardSize || j < 1 || j > BoardSize)
        throw rangeError("bad index in setCell");

    // Validate value is within allowed Sudoku range
    if (val < MinValue || val > MaxValue)
        throw rangeError("bad value in setCell");

    // Assign value to board
    value[i][j] = val;

    // Update row/column/square tracking
    updateConflicts();
}


void board::clearCell(int i, int j)
{
    // Clear cell
    // Validate indices
    if (i < 1 || i > BoardSize || j < 1 || j > BoardSize)
        throw rangeError("bad index in clearCell");

    // Set cell back to Blank
    value[i][j] = Blank;

    // Update constraint tracking
    updateConflicts();
}


void board::updateConflicts()
{
    // Update conflicts (Improved approach)
    // Reset all tracking arrays to false
    for (int i = 1; i <= BoardSize; i++)
        for (int j = 1; j <= BoardSize; j++)
        {
            rowCheck[i][j] = false;
            colCheck[i][j] = false;
            squareCheck[i][j] = false;
        }

    // Rebuild tracking arrays based on current board state
    for (int i = 1; i <= BoardSize; i++)
    {
        for (int j = 1; j <= BoardSize; j++)
        {
            // Only process non blank cells
            if (!isBlank(i, j))
            {
                int val = value[i][j];
                int sq = squareNumber(i, j);

                // Mark value as present in row, column, and square
                rowCheck[i][val] = true;
                colCheck[j][val] = true;
                squareCheck[sq][val] = true;
            }
        }
    }
}


void board::print()
{
    // Print board
    // Print the Sudoku board with grid formatting
    for (int i = 1; i <= BoardSize; i++)
    {
        // Print horizontal separators between squares
        if ((i - 1) % SquareSize == 0)
        {
            cout << " -";
            for (int j = 1; j <= BoardSize; j++)
                cout << "---";
            cout << "-\n";
        }

        for (int j = 1; j <= BoardSize; j++)
        {
            // Print vertical separators between squares
            if ((j - 1) % SquareSize == 0)
                cout << "|";

            // Print value or blank space
            if (!isBlank(i, j))
                cout << " " << getCell(i, j) << " ";
            else
                cout << "   ";
        }
        cout << "|\n";
    }

    // Print bottom border
    cout << " -";
    for (int j = 1; j <= BoardSize; j++)
        cout << "---";
    cout << "-\n";
}


void board::printConflicts()
{
    // Print conflicts
    // Output missing values for each row
    cout << "\nConflict Check:\n";

    for (int i = 1; i <= BoardSize; i++)
    {
        for (int val = 1; val <= BoardSize; val++)
        {
            if (!rowCheck[i][val])
                cout << "Row " << i << " missing " << val << endl;
        }
    }
}


bool board::isSolved()
{
    // Check solved
    // Verify every row, column, and square contains all values
    for (int i = 1; i <= BoardSize; i++)
    {
        for (int val = 1; val <= BoardSize; val++)
        {
            if (!rowCheck[i][val] ||
                !colCheck[i][val] ||
                !squareCheck[i][val])
                return false;
        }
    }

    // If all constraints satisfied, board is solved
    cout << "Board is solved!\n";
    return true;
}

// Project#4 Sudoku Part A 
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Header file for the board class
// Contains declarations for representing and manipulating a Sudoku board

#ifndef BOARD_H
#define BOARD_H

#include <iostream>
#include <vector>
#include <fstream>
#include "d_matrix.h"
#include "d_except.h"

using namespace std;

// type stored in each cell
typedef int ValueType;

// constants defining board properties
const int Blank = -1;
const int SquareSize = 3;
const int BoardSize = SquareSize * SquareSize;
const int MinValue = 1;
const int MaxValue = 9;

// board class definition
class board
{
public:
    // constructor
    board(int);

    // clear entire board
    void clear();

    // initialize board from file
    void initialize(ifstream &fin);

    // print board layout
    void print();

    // print missing values per row
    void printConflicts();

    // check if cell is blank
    bool isBlank(int, int);

    // get value stored in a cell
    ValueType getCell(int, int);

    // assign value to a cell
    void setCell(int, int, int);

    // clear a specific cell
    void clearCell(int, int);

    // check if board is solved
    bool isSolved();

private:
    // matrix storing board values
    matrix<ValueType> value;

    // conflict tracking matrices
    matrix<bool> rowCheck;
    matrix<bool> colCheck;
    matrix<bool> squareCheck;

    // determine which 3x3 square a cell belongs to
    int squareNumber(int i, int j);

    // update constraint tracking structures
    void updateConflicts();
};

#endif
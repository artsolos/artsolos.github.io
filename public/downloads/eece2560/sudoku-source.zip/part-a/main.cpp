// Project#4 Sudoku Part A 
// Group #9 
// MAHRUAKORKLI
// Diego Klish, Gaurav Koratagere, Arefin Mahmood, Jiawen Ruan
// EECE 2560
//
// Reads Sudoku boards from a user specified file before then 
// printing the board as well as conflicts and solved status

#include <iostream>
#include <fstream>
#include "board.h"

using namespace std;

int main()
{
    ifstream fin;
    string fileName;

    // Prompt user for input file
    cout << "Enter input file name: ";
    cin >> fileName;

    // Open the file
    fin.open(fileName.c_str());

    // Check if file opened successfully
    if (!fin)
    {
        cerr << "Cannot open " << fileName << endl;
        return 1;
    }

    try
    {
        // Create Sudoku board object
        board b(SquareSize);

        // Process boards until sentinel 'Z' is reached
        while (fin && fin.peek() != 'Z')
        {
            // Initialize board from file
            b.initialize(fin);

            // Print board layout
            b.print();

            // Print conflict information
            b.printConflicts();

            // Check if board is solved
            if (b.isSolved())
                cout << "Solved!\n";
            else
                cout << "Not solved.\n";
        }
    }
    catch (indexRangeError &ex)
    {
        // Catch and display any index errors
        cout << ex.what() << endl;
    }

    return 0;
}